create database bd_meuBanco;
use bd_meuBanco;

create table tb_livro(
id_livro int primary key auto_increment,
nm_livro varchar(45),
dt_ano date,
dt_cadastro date,
qt_examplares int(9)
);